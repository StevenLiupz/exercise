<template>
  <div class="task">
    <div class="text">分包1</div>
  </div>
</template>

<script>
export default {
  data () {
    return {}
  }
}
</script>

<style lang="less" scoped>
.task {
  height: 100%;
  .text {
    color: red;
  }
}
</style>
