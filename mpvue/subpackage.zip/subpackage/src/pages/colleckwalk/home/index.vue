<template>
  <div class="task">分包 colleckWalk</div>
</template>

<script>
export default {
  data () {
    return {}
  }
}
</script>

<style>
.task {
  height: 100%;
}
</style>
